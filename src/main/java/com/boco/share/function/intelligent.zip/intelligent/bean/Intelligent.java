/**
 * 
 */
package com.boco.share.function.intelligent.bean;

/**
 * @author lv
 *
 */
public class Intelligent {

	private String question;
	
	private String similarity;

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getSimilarity() {
		return similarity;
	}

	public void setSimilarity(String similarity) {
		this.similarity = similarity;
	}
	
	
	
}
