package com.boco.share.function.intelligent.dao;

/**
 * @author lv
 *
 */
public interface IntelligentMapper {

	/**
	 * 保存问题
	 * @param question
	 */
	public void saveQuestion(String question);
	
}
